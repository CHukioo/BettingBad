<?php 

session_start();
?>

<?php

$username = $_POST['username'];
$password = $_POST['password'];

if (is_null($username) && is_null($password)) {
	$username = $_SESSION['usernameMy'];
	$password = $_SESSION['passwordMy'];
}

$username = stripcslashes($username);
$password = stripcslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);


mysql_connect("localhost", "root", "root");
mysql_select_db("betting_bad");

$result = mysql_query("select * from user where username='$username' and password='$password' and confirm = 1") or die("Nemom da pristapam ".mysql_error());
$row = mysql_fetch_array($result);
if ($row['username'] == $username && $row['password'] == $password) {
	if ($username == "") {
		echo "YOU ARE NOT LOGEDIN. PLEASE <a href='login.php'>LOGIN</a>";
	}
	else{
		echo "HELLO: ".$username;
		$_SESSION['usernameMy'] = $username;
		$_SESSION['passwordMy'] = $password;
		header('Location: bettings.php?username='.$username);
		echo "<form action='logout.php' method='post'> <input type='submit' value='LOGOUT'></form>";
	}
}
else {
	header('Location: login.php?tocno=1');
}
?>