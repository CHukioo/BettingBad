<!DOCTYPE html>
<html>
<head>
	<title>BettingBad- Bettings</title>
	<link rel="stylesheet" type="text/css" href="styles/betting.css">
	<link rel="icon" href="images/handshake.png" type="image/gif" sizes="16x16">
</head>
<header>
	<div class="menu">
	<a href="index.php"><img src="images/handshake.png" class="logo"></a>
	<nav>
		<a href="#about" class="button">BETTINGS</a>
		<a href="#mobile" class="button">PLAYER SEARCH</a>
		<a href="#contact" class="button">MY PROFILE</a>
		<a href="logout.php" class="button">LOG OUT</a>
	</nav>
	</div>
</header>
<body>
</body>
</html>